# add your save-note function here
import boto3
import json
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("lotion-30153653")

def lambda_handler(event, context):

    body = json.loads(event['body'])
    try:
        table.put_item(
            Item=body
        )
        return {
            'statusCode': 201,
            'body': "success"
        }

    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'body': json.dumps({
                "message": str(e)
            })
        }